class ChangeSubs < ActiveRecord::Migration[5.2]
  def change
    remove_index :subs, :moderator_id 
    remove_index :posts, :sub_id
    remove_index :posts, :user_id
    add_index :subs, :moderator_id 
    add_index :posts, :sub_id
    add_index :posts, :user_id
  end
end
